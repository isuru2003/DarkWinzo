<div align="center">
<h1>🍁  ❤ Whatsapp Bot By Ravindu Manoj ❤  🍁</h1>
</div>
<div align="center">
<img src="https://github.com/Sew01RaviduManoj01KingAndQueen/imagehosting/blob/00aa7f2685f0114a2111f57149d8f0a27b2481c9/VID-20210724-WA0003.gif" />
  </div>


## 🇱🇰 RAVINDU MANOJ 🇱🇰  
### SEW BOT FOR YOUR HELP😇

- [RavinduManoj](https://github.com/RavinduManoj)
- [@RavinduManoj](https://t.me/RavinduManoj)



<div align="center">
  <img src="https://github.com/RavinduManoj/imagehosting/blob/e18b9131ed1b5ec87d58359781c2a9c1044df810/temp_user_profile1621662133773.jpeg" width="250" height="250">
  <h1>🍁  Whatsapp Bot By Ravindu Manoj  🍁</h1>
  <h1>🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰</h1>
</div>
<p align="center">
    WhatsAsena project - Makes it easy and fun to use Whatsapp. Also first userbot for Whatsapp.
    <br>
        <a href="https://t.me/RavinduManoj">Telegram Number</a> |
        <a href="https://t.me/AsenaSupport">Telegram Group</a> |
        <a href="https://t.me/asenaremaster">New Support Group</a> |
        <a href="https://t.me/unofficialplugin">New Plugin Channel</a> |
    <br>
</p>



##

### ⚒️ Setup Wiki - Kurulum [Full Guide - By Ravindu Manoj]
[![Setup - Raviya](https://github.com/RavinduManoj/imagehosting/blob/7d17c40df5099525556eb014b20a13eca4ac1176/20210628_090852.png?size=75 )](https://github.com/RavinduManoj/RaviyaBot/wiki)

##

### 🇱🇰 ⚠️ Warning! 
```
Due to Userbot; Your WhatsApp account may be banned.
This is an open source project, you are responsible for everything you do. 
Absolutely, Asena executives do not accept responsibility.
By establishing the Asena, you are deemed to have accepted these responsibilities.
```

##🇱🇰 Developer 🍁

[![RAVINDU MANOJ](https://github.com/RavinduManoj/imagehosting/blob/e18b9131ed1b5ec87d58359781c2a9c1044df810/temp_user_profile1621662133773.jpeg" width="100" height="100")](https://www.fusuf.codes)

## Thanks To
- [@adiwajshing](https://github.com/adiwajshing) for coded [Baileys](https://github.com/adiwajshing/Baileys) 

## License
This project is protected by `GNU General Public Licence v3.0` license.

### Disclaimer
`WhatsApp` name, its variations and the logo are registered trademarks of Facebook. We have nothing to do with the registered trademark

<div align="center">
  <img src="https://github.com/RavinduManoj/imagehosting/blob/7d17c40df5099525556eb014b20a13eca4ac1176/IMG_20210628_090553.jpg" width="250" height="250">
  <h1>🍁  Whatsapp Bot By Ravindu Manoj  🍁</h1>
  <h1>🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰🇱🇰</h1>
</div>
