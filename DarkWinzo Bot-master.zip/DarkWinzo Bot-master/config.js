/* Codded by @IsurLakshan

Telegram: t.me/Isuru

Licensed under the  GPL-3.0 License;
you may not use this file except in compliance with the License.

Whats bot - DarkWinzo
*/

const { Sequelize } = require('sequelize');
const fs = require('fs');
if (fs.existsSync('config.env')) require('dotenv').config({ path: './config.env' });

function convertToBool(text, fault = 'true') {
    return text === fault ? true : false;
}

DATABASE_URL = process.env.DATABASE_URL === undefined ? './DarkWinzo.db' : process.env.DATABASE_URL;
DEBUG = process.env.DEBUG === undefined ? false : convertToBool(process.env.DEBUG);

module.exports = {
    VERSION: 'DarkWinzo 1.0.0 - Full Control',
    CHANNEL: 'https://t.me/MotivationSL',
    SESSION: process.env._DARKWINZO_SESSION === undefined ? '' : process.env._DARKWINZO_SESSION,
    ANTİLİNK: process.env.ANTİ_LİNK === undefined ? 'false' : process.env.ANTİ_LİNK,
    INBO: process.env.INBO_BLOCK === undefined ? 'false' : process.env.INBO_BLOCK,
    Bad_Word: process.env.BAD_KICK === undefined ? 'false' : process.env.BAD_KICK,
    PSW: process.env.BOT_MODE === undefined ? 'DarkWinzo' : process.env.BOT_MODE,
    PSD: process.env.PASS_WORD_SES === undefined ? 'isuru' : process.env.PASS_WORD_SES,
    PROXY: process.env.PROXY === undefined ? 'false' : process.env.PROXY,
    AUTOBİO: process.env.AUTO_BİO === undefined ? 'false' : process.env.AUTO_BİO,
    DEEPAI: process.env.DEEP_AI === undefined ? '09010100-625c-46c4-b226-8f9a5e6e548f' : process.env.DEEP_AI,
    ABT: process.env.AUTO_BİO_ABOUT === undefined ? 'Coded By Isuru Lakshan' : process.env.AUTO_BİO_ABOUT,
    GANSTYLE: process.env.GAN_IMAGE === undefined ? 'https://i.hizliresim.com/loUtAb.jpg' : process.env.GAN_IMAGE,
    LANG: process.env.LANGUAGE === undefined ? 'EN' : process.env.LANGUAGE.toUpperCase(),
    TEXT: process.env.TEXTTEXTTEXT === undefined ? 'DARS' : process.env.TEXTTEXTTEXT.toUpperCase(),
    ALIVEMSG: process.env.ALIVE_MESSAGE === undefined ? 'Coded By Isuru Lakshan \n\n Join The Telegrame Group \nt.me/MotivationSL\n\n' : process.env.ALIVE_MESSAGE,
    KICKMEMSG: process.env.KICKME_MESSAGE === undefined ? 'default' : process.env.KICKME_MESSAGE,
    BLOCKCHAT: process.env.BLOCK_CHAT === undefined ? false : process.env.BLOCK_CHAT,
    ADDMSG: process.env.ADD_MESSAGE === undefined ? 'default' : process.env.ADD_MESSAGE,
    MUTEMSG: process.env.MUTE_MESSAGE === undefined ? 'default' : process.env.MUTE_MESSAGE,
    VOICEFILTER: process.env.VOICE_REPLY === undefined ? false : convertToBool(process.env.VOICE_REPLY),
    CPK: process.env.CAPTION_NAME === undefined ? 'Coded By t.me/MotivationSL' : process.env.CAPTION_NAME,
    MCMD: process.env.MAIN_COMMAND === undefined ? 'DARK' : process.env.MAIN_COMMAND,
    ALIMG: process.env.SYSTEM_IMAGE === undefined ? 'https://i.ibb.co/RzSZW8F/IMG-20210810-WA0005.jpg' : process.env.SYSTEM_IMAGE,
    DARKP: process.env.X_TEAM_API_A === undefined ? 'd9f297dbf7b0bbf4' : process.env.X_TEAM_API_A,
    DARKO: process.env.X_TEAM_API_B === undefined ? 'c809c9b2f07400c2' : process.env.X_TEAM_API_B,
    DARKN: process.env.X_TEAM_API_C === undefined ? '6ffb0caa0165c0e6' : process.env.X_TEAM_API_C,
    DARKM: process.env.X_TEAM_API_D === undefined ? '7d9712378e88936a' : process.env.X_TEAM_API_D,
    DARKL: process.env.X_TEAM_API_E === undefined ? '247853f9489fd9dd' : process.env.X_TEAM_API_E,
    DARKK: process.env.X_TEAM_API_F === undefined ? '47bd16bd0d1f5dd9' : process.env.X_TEAM_API_F,
    DARKJ: process.env.X_TEAM_API_G === undefined ? 'f5fac49952b0f9fd' : process.env.X_TEAM_API_G,
    DARKI: process.env.X_TEAM_API_H === undefined ? 'e28ddd615308dc15' : process.env.X_TEAM_API_H,
    DARKH: process.env.X_TEAM_API_I === undefined ? '6e8843a1b96c1b55' : process.env.X_TEAM_API_I,
    DARKG: process.env.X_TEAM_API_J === undefined ? '0ee332ecf9252b8e' : process.env.X_TEAM_API_J,
    DARKF: process.env.X_TEAM_API_K === undefined ? '929b8d6bc1dbba2d' : process.env.X_TEAM_API_K,
    DARKE: process.env.X_TEAM_API_L === undefined ? '608c95b6e98badf2' : process.env.X_TEAM_API_L,
    DARKD: process.env.X_TEAM_API_M === undefined ? 'fe1a79b7f94e0895' : process.env.X_TEAM_API_M,
    DARKC: process.env.X_TEAM_API_N === undefined ? 'fff22c3b31155a13' : process.env.X_TEAM_API_N,
    DARKB: process.env.X_TEAM_API_O === undefined ? '3996a91c7fca6ee7' : process.env.X_TEAM_API_O,
    DARKA: process.env.X_TEAM_API_P === undefined ? '53859a9d6bbb75cd' : process.env.X_TEAM_API_P,
    DARKQ: process.env.X_TEAM_API_Q === undefined ? 'b73460ebf0b78fba' : process.env.X_TEAM_API_Q,
    RGMSE: process.env.ZENZ_API_E === undefined ? 'b530f1a72e' : process.env.ZENZ_API_E,
    RGMSD: process.env.ZENZ_API_D === undefined ? '4c39c1d430c0' : process.env.ZENZ_API_D,
    RGMSC: process.env.ZENZ_API_C === undefined ? '283ad91cbc' : process.env.ZENZ_API_C,
    RGMSB: process.env.ZENZ_API_B === undefined ? '1606ea72e2' : process.env.ZENZ_API_B,
    RGMSA: process.env.ZENZ_API_A === undefined ? 'aca83a4354ac' : process.env.ZENZ_API_A,
    GIFORPP: process.env.Y__GREETING_TYPE === undefined ? 'pp' : process.env.Y__GREETING_TYPE,
    WLP: process.env.Y_WELLCOME === undefined ? 'https://i.ibb.co/TwDZC28/Welcome-poster-with-spectrum-brush-strokes-on-white-background-Colorful-gradient-brush-design-Vector.jpg' : process.env.Y_WELLCOME,
    GDB: process.env.Y_GOODBYE === undefined ? 'https://i.ibb.co/Scj56Wd/Good-Bye-neon-text-vector-design-template-Good-Bye-neon-logo-light-banner-design-element-colorful-mo.jpg' : process.env.Y_GOODBYE,
    DARKRR: process.env.ZZ_PASSWORD === undefined ? '' : process.env.ZZ_PASSWORD,
    DISBGM: process.env.DISABLE_JID_BGM_FILTER === undefined ? false : process.env.DISABLE_JID_BGM_FILTER,
    NOLOG: process.env.NO_LOG === undefined ? 'false' : process.env.NO_LOG,
    OWNERSHIP: process.env.OWNER_SHIP === undefined ? 'ISURU LAKSHAN' : process.env.OWNER_SHIP,
    BOTNAME: process.env.YOUR_BOT_NAME === undefined ? '❄DarkWinnzo(💗ඩාර්ක්වින්සෝ💗)I💌N' : process.env.YOUR_BOT_NAME,
    FULLDARK: process.env.FULL_DARK === undefined ? 'false' : process.env.FULL_DARK,
    BLOCKMSG: process.env.BLOCK_MESSAGE === undefined ? 'default' : process.env.BLOCK_MESSAGE,
    UNBLOCKMSG: process.env.UNBLOCK_MESSAGE === undefined ? 'default' : process.env.UNBLOCK_MESSAGE,
    UNMUTEMSG: process.env.UNMUTE_MESSAGE === undefined ? 'default' : process.env.UNMUTE_MESSAGE,
    WORKTYPE: process.env.WORK_TYPE === undefined ? 'private' : process.env.WORK_TYPE,
    PROMOTEMSG: process.env.PROMOTE_MESSAGE === undefined ? 'default' : process.env.PROMOTE_MESSAGE,
    DEMOTEMSG: process.env.DEMOTE_MESSAGE === undefined ? 'default' : process.env.DEMOTE_MESSAGE,
    BANMSG: process.env.BAN_MESSAGE === undefined ? 'default' : process.env.BAN_MESSAGE,
    AUTOSTICKER: process.env.AUTO_STICKER === undefined ? false : convertToBool(process.env.AUTO_STICKER),
    DISSTICKER: process.env.DISABLE_STICKER === undefined ? false : process.env.DISABLE_STICKER,
    AFKMSG: process.env.AFK_MESSAGE === undefined ? 'default' : process.env.AFK_MESSAGE,
    HANDLERS: process.env.HANDLERS === undefined ? '^[.!;]' : process.env.HANDLERS,
    SEND_READ: process.env.SEND_READ === undefined ? false : convertToBool(process.env.SEND_READ),
    BRANCH: 'master',
    HEROKU: {
        HEROKU: process.env.HEROKU === undefined ? false : convertToBool(process.env.HEROKU),
        API_KEY: process.env.HEROKU_API_KEY === undefined ? '' : process.env.HEROKU_API_KEY,
        APP_NAME: process.env.HEROKU_APP_NAME === undefined ? '' : process.env.HEROKU_APP_NAME
    },
    DATABASE_URL: DATABASE_URL,
    DATABASE: DATABASE_URL === './DarkWinzo.db' ? new Sequelize({ dialect: "sqlite", storage: DATABASE_URL, logging: DEBUG }) : new Sequelize(DATABASE_URL, { dialectOptions: { ssl: { require: true, rejectUnauthorized: false } }, logging: DEBUG }),
    RBG_API_KEY: process.env.REMOVE_BG_API_KEY === undefined ? false : process.env.REMOVE_BG_API_KEY,
    NO_ONLINE: process.env.NO_ONLINE === undefined ? true : convertToBool(process.env.NO_ONLINE),
    SUDO: process.env.SUDO === undefined ? false : process.env.SUDO,
    DEBUG: DEBUG,
    COFFEEHOUSE_API_KEY: process.env.COFFEEHOUSE_API_KEY === undefined ? false : process.env.COFFEEHOUSE_API_KEY,
    WITAI_API: "TEYMELA6DMC4XB5YM3SPTTQWUUIBKURG",
    RRRRA: "393475528094-1415817281",
    RRRRB: "96176912958-1458298055",
    RRRRC: "393472769604-1446476993",
    RRADARK: "94785435462-1621751150",
    RRBDARK: "94785435462-1625490851",
    RRCDARK: "94785435462-1618586156",
    RRDDARK: "94776785357-1626432386",
    RREDARK: "94776785357-1626521320",
    RRFDARK: "94785435462-1618915104",
    SUPPORT: "94785435462-1627812354",
    SUPPORT2: "94785435462-1628835469",
    SUPPORT3: "94785435462-1628835633",
    GRP1S: "94757405652-1631633729",
    GRP2S: "94757405652-1631905677",
    GRP3S: "94711870791-1631902138"
};
