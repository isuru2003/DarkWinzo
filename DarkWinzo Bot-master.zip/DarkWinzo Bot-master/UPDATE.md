# මෙහි DarkWinzo බොට්ගේ සිදුවන අප්ඩේට්ස් ඇතුලත් වේ.. 

## සටහන් ආරම්බ කල දිනය :- 2021 August 27

# DarkWinzo

# 2021 - November - 01

*♕❄DarkWinzo 1.0.0 - Full Control - Dual Bot Mode❄♔*

1st bot
*✨DarkWinzo Whatsapp Bot ✨★➳*


❯❯❯added new ttp list ==> .Darkttp

❯❯❯new unit convart system ==> .unit 1 kg g / .bitunit 1 Gb Mb

❯❯❯site to pdf ==> .sitepdf

❯❯❯inbox block system ==> for activate  .setvar INBO_BLOCK:true  for disable  .setvar INBO_BLOCK:false

❯❯❯anime image and gif download 100000+ ==> .anime pic / .anime gif

❯❯❯carbon image make upgaded ==> .carbon

❯❯❯adding voice massage with Fake Recording option

❯❯❯fixed some bot bugs and antispam system

❯❯❯try to fix facebook download error ==> .fb

❯❯❯adding mediafire Download ==> .mapk / .mzip

❯❯❯spotify download ==> .spotyfi 

❯❯❯new text maker list ==> .Dark3maker (adding 100+ new text to image soonly)

❯❯❯dual bot mod ==> .Isuru && .DarkWinzo or .setvar BOT_MODE:Isuru && .setvar BOT_MODE:DarkWinzo


2nd Bot
*✨DarkWinzo 18 + whatsapp bot ✨★➳*


❯❯❯phub search ==> .pornhub your text

❯❯❯phub search list download ==> .xxx link

❯❯❯xnxx download  ==> .xnxx link 

❯❯❯porn pic ==> check the .18plus

❯❯❯porn gif ==> check the .18plus

&& Fixed some Errors And Bugs



*DarkWoinzo 1.0.0  - FULL CONTROL - ද්විත්ව බොට් ප්‍රකාරය♔*

1 වන බොට්
*DarkWinzo Whatsapp Bot★ ➳*


❯❯❯නව ttp ලැයිස්තුව එකතු කරන ලදි ==> .Darkttp

❯❯❯නව ඒකක පරිවර්තන ගැන්වීමේ පද්ධතිය ==> .unit 1 kg  g / .bitunit 1 Gb Mb

❯❯❯වෙබ් අඩවිය pdf බවට ==> .sitepdf

❯❯❯ඉන්බොක්ස් පැමිනෙන අය බ්ලොක් කිරීමේ පද්දතිය ==> සක්‍රිය කිරීම සඳහා .setvar INBO_BLOCK:true අක්‍රීය කිරීම සඳහා setvar INBO_BLOCK:false

❯❯❯ඇනිමෙ ප්‍රතිරූපය සහ ගිෆ් බාගැනීම් 100000+ ==> .anime pic / .anime gif

❯❯❯carbon image ඉහළ නංවා ඇත ==> .carbon

❯❯❯ව්‍යාජ පටිගත කිරීමේ විකල්පය සමඟ voice massage  එකතු කිරීම

❯❯❯සමහර බොට් bug  සහ ඇන්ටිස්පෑම් පද්ධතිය upgrade කර ඇත

❯❯❯ෆේස්බුක් බාගැනීමේ දෝෂය නිවැරදි කිරීමට උත්සාහ කරන්න ==> .fb

❯❯❯මීඩියාෆයර් ලින්ක් ඩදුන්ලෝඩ් එකතු කිරීම ==> .mapk / .mzip

❯❯❯spotify බාගැනීම ==> .spotyfi

❯❯❯නව ලෝගො මේකර් ලැයිස්තුව ==> .Dark3maker (ඉක්මනින් පින්තූරයට නව පෙළ 100+ එකතු කිරීම)

❯❯❯ද්විත්ව බොට් මොඩ් (බොට්ව මාරු කිරීම සදහා යොදා ගන්න ) ==> .Isuru && .DarkWinzo


2 වෙනි බොට් 
*DarkWinzo 18 + වට්ස්ඇප් බොට් ★ ➳*


❯❯❯pornhub සෙවුම ==> .pornhub your text

❯❯❯ඉහත සෙවුම් ලැයිස්තුව බාගන්න ==> .xxx link

❯❯❯xnxx බාගැනීම ==> .xnxx link

❯❯❯කාමුක පින්තූර ==> .18plus පරීක්‍ෂා කරන්න

❯❯❯කාමුක gif ==> .18plus පරීක්‍ෂා කරන්න

&& සමහර දෝෂ නිරාකරණය කර ඇත


fixed all bugs 2021 september 04




