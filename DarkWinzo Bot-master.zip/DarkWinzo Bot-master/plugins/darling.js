/* Codded by @Isuru Lakshan

Telegram: t.me/Isuru

Licensed under the  GPL-3.0 License;
you may not use this file except in compliance with the License.

Whats bot - Ravindu Manoj
*/
const DarkWinzo = require('../events');
const DARK = "*ᴘᴏᴡᴇʀᴅ ʙʏ DarkWinzo*\n ඔබේ පෙම්වතිය හෝ පෙම්වතා වෙත සොදුරු ඇමතුමක්.\n💻Usage: *.msglv*"
const fs = require('fs')
const {MessageType, Mimetype } = require('@adiwajshing/baileys');
const Config = require('../config')
 if (Config.PSW !== 'isuru') {
DarkWinzo.newcmdaddtoDark({pattern: 'msglv', fromMe: false, desc: DARK }, (async (message, match) => {
var Darkrm = new Array ();
Darkrm [0] = "zzaaa"
Darkrm [1] = "zzaab"
Darkrm [2] = "zzaac"
Darkrm [3] = "zzaad"
Darkrm [4] = "zzaae"
Darkrm [5] = "zzaaf"
Darkrm [6] = "zzaag"
Darkrm [7] = "zzaah"
Darkrm [8] = "zzaai"
Darkrm [9] = "zzaaj"
Darkrm [10] = "zzaak"
Darkrm [11] = "zzaal"
Darkrm [12] = "zzaam"
var s = Math.floor(13*Math.random())
await message.client.sendMessage(message.jid, fs.readFileSync('./VoiceClip/' + '${Darkrm[s]}' + '.mp3'), MessageType.sticker, { mimetype: Mimetype.webp, ptt: false})
}));
}
