const DarkWinzo = require('../events');
const {MessageType, MessageOptions, Mimetype} = require('@adiwajshing/baileys');
const axios = require('axios');
const { errorMessage, infoMessage } = require('../helpers');
const isuru = require('../config');
var r_text = new Array ();
r_text[1] = isuru.RGMSA
r_text[2] = isuru.RGMSB
r_text[3] = isuru.RGMSC
r_text[4] = isuru.RGMSD
r_text[5] = isuru.RGMSE

var i = Math.floor(5*Math.random())

if (isuru.PSW !== 'isuru') {
        
DarkWinzo.newcmdaddtoDark({ pattern: 'tiktok ?(.*)', fromMe: true, disc: 'tiktok video download without watermark'}, async (message, match) => {
        const Darktik = match[1]
        if (!Darktik) return await message.client.sendMessage(message.jid,'need tiktok link',MessageType.text);
         await message.client.sendMessage(message.jid,'downloading your video',MessageType.text)
        await axios
          .get(`https://zenzapi.xyz/api/downloader/tiktok?url=${Darktik}&apikey=${r_text[i]}`)
          .then(async (response) => {
            const {
              nowatermark,
            } = response.data.result
    
            const videoBuffer = await axios.get(nowatermark, {responseType: 'arraybuffer'})
    
            await message.client.sendMessage(message.jid,'uploading your video',MessageType.text, {quoted: message.data});
            await message.client.sendMessage(message.jid,Buffer.from(videoBuffer.data), MessageType.video, {mimetype: Mimetype.mp4, ptt: false})
        })
        .catch(
          async (err) => await message.client.sendMessage(message.jid,'cant find 🥴🥴🥴',MessageType.text, {quoted: message.data}),
        )});

DarkWinzo.newcmdaddtoDark({ pattern: 'tiktok ?(.*)', fromMe: false, disc: 'tiktok video download without watermark'}, async (message, match) => {
        const Darktik = match[1]
        if (!Darktik) return await message.client.sendMessage(message.jid,'need tiktok video link',MessageType.text);
         await message.client.sendMessage(message.jid,'downloading your video',MessageType.text)
        await axios
          .get(`https://zenzapi.xyz/api/downloader/tiktok?url=${Darktik}&apikey=${r_text[i]}`)
          .then(async (response) => {
            const {
              nowatermark,
            } = response.data.result
    
            const videoBuffer = await axios.get(nowatermark, {responseType: 'arraybuffer'})
    
            await message.client.sendMessage(message.jid,'uploading your video',MessageType.text, {quoted: message.data});
            await message.client.sendMessage(message.jid,Buffer.from(videoBuffer.data), MessageType.video, {mimetype: Mimetype.mp4, ptt: false})
        })
        .catch(
          async (err) => await message.client.sendMessage(message.jid,'cant find 🥴🥴🥴',MessageType.text, {quoted: message.data}),
        )});
}
