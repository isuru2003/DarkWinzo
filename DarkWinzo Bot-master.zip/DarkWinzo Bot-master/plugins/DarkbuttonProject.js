/* Codded by @Isuru Lakshan

Telegram: t.me/Isuru
Whatsapp: Wa.me/+1(772)205-6515

Licensed under the  GPL-3.0 License;
you may not use this file except in compliance with the License.

Whats bot - DarkWinzo

This Is Official Pluging From Isuru Lakshan

const Isuru = require('textDarkmake');  // button msg npm export
const DarkWinzo = require('../events');
const {MessageType, MessageOptions, Mimetype} = require('@adiwajshing/baileys');
const exec = require('child_process').exec;
const os = require("os");
const fs = require('fs');
const got = require('got');
const axios = require('axios');
const Config = require('../config');
//cd resources for button test
var rgms = { cd: 'L3Jvb3QvUXVlZW5TZXdXaGF0c2FwcEJvdC8=', pay: '' }    
var rrrr = Buffer.from(rgms.cd, 'base64')
var ssss = rrrr.toString('utf-8')
rgms.pay = ssss
if (os.userInfo().homedir !== rgms.pay) return;
if (Config.DARKRR == 'isuru') {
DarkWinzo.newcmdaddtoDark({pattern: 'testb ?(.*)', fromMe: true, delownDarkcmd: false,}, (async (message, match) => {
var reply = await message.client.sendMessage(message.jid,'test',MessageType.text);
var rows = [
 {title: 'Row 1', description: "Hello it's description 1", rowId:"rowid1"},
 {title: 'Row 2', description: "Hello it's description 2", rowId:"rowid2"}
]
//This Is Official Pluging From Isuru Lakshan
var sections = [{title: "Section 1", rows: rows}]
var button = {
 buttonText: 'DarkWinzo',
 description: "Button Checking",
 sections: sections,
 listType: 1
}
await message.client.sendMessage(message.jid, button, MessageType.listMessage)
//exec.addbutton-Isuru Lakshan(1.0.0)
 const buttons = [
  {buttonId: 'id1', buttonText: {displayText: 'Button 1'}, type: 1},
  {buttonId: 'id2', buttonText: {displayText: 'Button 2'}, type: 1}
]

const buttonMessage = {
    contentText: "Isuru",
    footerText: 'Button Msg Chack',
    buttons: buttons,
    headerType: 1
}

await message.client.sendMessage(message.jid, buttonMessage, MessageType.buttonsMessage)

    }));
    }
*/
