/* Codded by @Isuru Lakshan

Telegram: t.me/Isuru

Licensed under the  GPL-3.0 License;
you may not use this file except in compliance with the License.

Whats bot - DarkWinzo

*/
const DarkWinzo = require('../events');
const {MessageType, MessageOptions, Mimetype} = require('@adiwajshing/baileys');
const axios = require('axios');
const Isuru = require('../config');
const {spawnSync} = require('child_process');
const fs = require('fs');
     
const DARKARR = "Dark Winzo session එක 👇"
const DARKBRR = Isuru.SESSION
const DARKAARR = "Heruku Api Key Eka👇"
const DARKABR = Isuru.API_KEY
const DARKYRR = "Qr එක ගැනීම සදහා යායුතු ලින්ක් එක 👇"
const DARKZRR = "https://replit.com/@RavinduManoj/Queen-DARK-QR-Code"
const DARKGRR = "Alive Msg eka"
const DARKHRR = Isuru.ALIVEMSG
const DARKIRR = "Xteam Api Key 1"
const DARKJRR = Isuru.DARKP
const DARKKRR = "Xteam Api Key 2"
const DARKLRR = Isuru.DARKO
const DARKMRR = "Xteam Api Key 3"
const DARKNRR = Isuru.DARKN
const DARKORR = "Xteam Api Key 4"
const DARKPRR = Isuru.DARKM
const DARKQRR = "වෙල්කම් මැසේජ් එකට අදාල ෆොටෝ එකෙහි ඩිරෙක්ට් ලින්ක් එක"
const DARKRRR = Isuru.WLP
const DARKSRR = "ගුඩ්බායි මැසේජ් එකට අදාල ෆොටෝ එකෙහි ඩිරෙක්ට් ලින්ක් එක"
const DARKTRR = Isuru.GDB
const DARKURR = "Base64 encoded 4to eka"
const DARKVRR = Isuru.THUM
const DARKERR = "System Image eka"
const DARKFRR = Isuru.ALIMG
const DARKCRR = "බොට් සෑදීම සදහා යා යුතු ලින්ක් එක"
const DARKDRR = "https://github.com/isuru2003/DarkWinzo.git"

DarkWinzo.newcmdaddtoDark({pattern: 'configlist', fromMe: true, disc: 'බොට්ව සෑදීමේදී ඔබ විසින් දමා ඇති දත්ත ලබා ගත හැක . your config details.' }, (async (message, match) => {
      await message.client.sendMessage(message.jid,'hear is your all config 😉', MessageType.text);
      await message.client.sendMessage(message.jid,DARKARR, MessageType.text);
      await message.client.sendMessage(message.jid,DARKBRR, MessageType.text);
      await message.client.sendMessage(message.jid,'👆👆👆👆', MessageType.text);
      await message.client.sendMessage(message.jid,DARKCRR, MessageType.text);
      await message.client.sendMessage(message.jid,DARKDRR, MessageType.text);
      await message.client.sendMessage(message.jid,'👆👆👆👆', MessageType.text);
      await message.client.sendMessage(message.jid,DARKERR, MessageType.text);
      await message.client.sendMessage(message.jid,DARKFRR, MessageType.text);
      await message.client.sendMessage(message.jid,'👆👆👆👆', MessageType.text);
      await message.client.sendMessage(message.jid,DARKGRR, MessageType.text);
      await message.client.sendMessage(message.jid,DARKHRR, MessageType.text);
      await message.client.sendMessage(message.jid,'👆👆👆👆', MessageType.text);
      await message.client.sendMessage(message.jid,DARKIRR, MessageType.text);
      await message.client.sendMessage(message.jid,DARKJRR, MessageType.text);
      await message.client.sendMessage(message.jid,'👆👆👆👆', MessageType.text);
      await message.client.sendMessage(message.jid,DARKKRR, MessageType.text);
      await message.client.sendMessage(message.jid,DARKLRR, MessageType.text);
      await message.client.sendMessage(message.jid,'👆👆👆👆', MessageType.text);
      await message.client.sendMessage(message.jid,DARKMRR, MessageType.text);
      await message.client.sendMessage(message.jid,DARKNRR, MessageType.text);
      await message.client.sendMessage(message.jid,'👆👆👆👆', MessageType.text);
      await message.client.sendMessage(message.jid,DARKORR, MessageType.text);
      await message.client.sendMessage(message.jid,DARKPRR, MessageType.text);
      await message.client.sendMessage(message.jid,'👆👆👆👆', MessageType.text);
      await message.client.sendMessage(message.jid,DARKQRR, MessageType.text);
      await message.client.sendMessage(message.jid,DARKRRR, MessageType.text);
      await message.client.sendMessage(message.jid,'👆👆👆👆', MessageType.text);
      await message.client.sendMessage(message.jid,DARKSRR, MessageType.text);
      await message.client.sendMessage(message.jid,DARKTRR, MessageType.text);
      await message.client.sendMessage(message.jid,'👆👆👆👆', MessageType.text);
      await message.client.sendMessage(message.jid,DARKURR, MessageType.text);
      await message.client.sendMessage(message.jid,DARKVRR, MessageType.text);
      await message.client.sendMessage(message.jid,'👆👆👆👆', MessageType.text);
      await message.client.sendMessage(message.jid,DARKWRR, MessageType.text);
      await message.client.sendMessage(message.jid,DARKXRR, MessageType.text);
      await message.client.sendMessage(message.jid,'👆👆👆👆', MessageType.text);
      await message.client.sendMessage(message.jid,DARKYRR, MessageType.text);
      await message.client.sendMessage(message.jid,DARKZRR, MessageType.text);
      await message.client.sendMessage(message.jid,'👆👆👆👆', MessageType.text);
      await message.client.sendMessage(message.jid,DARKAARR, MessageType.text);
      await message.client.sendMessage(message.jid,DARKABRR, MessageType.text);
      await message.client.sendMessage(message.jid,'👆👆👆👆', MessageType.text);
   }));
