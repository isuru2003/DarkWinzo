/* Codded by @Isuru Lakshan

Telegram: t.me/RavinduManoj

Licensed under the  GPL-3.0 License;

you may not use this file except in compliance with the License.

Whats bot - DarkWinzo
*/

const DarkWinzo = require('../events');
const {MessageType} = require('@adiwajshing/baileys');

DarkWinzo.newcmdaddtoDark({pattern: 'enmpack', fromMe: false}, (async (message, match) => {

    await message.sendMessage("_A plugin where different and fun things are found together._\n💻Usage: *.enm1*\nℹ️Desc: *Turn to your love into a balloon with mini picture.*\n\n💻Usage: *.enm2*\nℹ️Desc: *Do you love me?*\n\n💻Usage: *.enm3*\nℹ️Desc: *Good Night, Sweet Dreams*\n\n💻Usage: *.enm4*\nℹ️Desc: *A cool good night message.*\n\n💻Usage: *.enm5*\nℹ️Desc: *Do you want to start the day with a one cup coffee?*\n\n💻Usage: *.enm6*\nℹ️Desc: *How to give a better greeting?*\n\nCodded by *t.me/MotivationSL*");

}));

DarkWinzo.newcmdaddtoDark({pattern: 'enm1', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage("╱▔▔╲╱▔▔╲\n▏┈╭╮╭╮┈▕ \n╲┈┏━━┓┈╱\n   ╲╰━━╯╱\n     ╲┈┈╱\n        ╲╱\n        🌷\n   ◢▇◣◢▇◣\n   ▇▇▇▇▇▇\n   ◥▇▇▇▇◤\n      ◥▇▇◤\n        ◥◤\n       🌷\n🔮🌹🍃🌹🍃🔮\n(¯•.•´¯) (¯•.•´¯)\n~•.¸(¯•.•´¯)¸ .•~\n×°× ` •.¸.•´ ×°×\n ˏ.٠•☼ • •·)\n ˙·٠•●•٠·˙ \n˙·٠•●•٠·˙☼✫ ღ 彡 \n♡ ➹ ᶫᵒᵛᵉ 彡 \n┊┊┊\n┊┊★\n┊★\n★");

}));

DarkWinzo.newcmdaddtoDark({pattern: 'enm2', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage("┏🌷️┓┏🌷️┓┏🌷️┓\n┗🌷️┛┗🌷️┛┗🌷┛\n☆°🍃🌸 *I Love You* 💕 \n☆°🍃🌸\n☆°🍃🌸\n☆°🍃‍🌸\n☆°🍃‍🌸\n☆°🍃‍🌸\n☆°🍃🌸️\n☆°🍃🌸 *Do you love me too?* 🥰\n┏🌷️┓┏🌷️┓┏🌷️┓\n┗🌷️┛┗🌷️┛┗🌷┛\n☆°🍃🌸\n☆°🍃🌸\n☆°🍃🌸\n☆°🍃‍🌸\n☆°🍃‍🌸\n☆°🍃‍🌸\n☆°🍃🌸️\n☆°🍃🌸");

}));

DarkWinzo.newcmdaddtoDark({pattern: 'enm3', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage("🌹🍃 *Good* \n┆🍃\n┆🌼\n┆┆🍃\n┆┆🌷\n┆┆┆🍃\n┆┆┆🌹\n┆┆┆┆\n┆┆┆┆\n┆┆┆┆\n┆┆┆🌹 *Night* \n┆┆┆┆🍃\n┆┆┆🌹\n┆┆┆🍃\n┆┆🌷\n┆┆🍃\n┆🌼\n┆🌹🍃\n🌹🍃\n┆🍃\n┆🌼\n┆┆🍃\n┆┆🌷 *Sweet* \n┆┆┆🍃\n┆┆┆🌹\n┆┆┆┆\n┆┆┆┆\n┆┆┆┆\n┆┆┆🌹 *Dreams* \n┆┆┆┆🍃\n┆┆┆🌻\n┆┆┆🍃\n┆┆🌷\n┆┆🍃\n┆🌼\n┆🌹🍃\n🌹🍃\n");

}));

DarkWinzo.newcmdaddtoDark({pattern: 'enm4', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage("🌷🌷🌷🌷🌷🌷\n🌷█▒▒▒▒▒▒▒▒▒█🌷🍃\n  🌸🌸🌸🌸🌸🌸🍃\n🌷█▒▒▒▒▒▒▒▒▒█🌷\n 🍃 *May your night be perfect* 🍃\n🌷█▒▒▒▒▒▒▒▒▒█🌷\n 🍃🌸🌸🌸🌸🌸🌸🍃\n🌷█▒▒▒▒▒▒▒▒▒█🌷\n🍃🌸🌸🌸🌸🌸🌸🍃\n🍃🌸🌸🌸🌸🌸🌸🍃\n🌷█▒▒▒▒▒▒▒▒▒█🌷🍃\n🍃🌸🌸🌸🌸🌸🌸🍃\n🌷█▒▒▒▒▒▒▒▒▒█🌷\n🍃 *Like You. Sweet Dreams* 🍃\n🌷█▒▒▒▒▒▒▒▒▒█🌷\n🍃 🌸🌸🌸🌸🌸🌸🍃\n🌷█▒▒▒▒▒▒▒▒▒█🌷\n  🌷🌷🌷🌷🌷🌷");

}));

DarkWinzo.newcmdaddtoDark({pattern: 'enm5', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage("💚 *Good* 💚\n   💚 *Morning* 💚\n  ===>♡☕️☕️♡<===\n        ┈┈╭╯╯╯┈\n     ┈┈┏━━━━┓\n     ┈╭┫╭▅╭▅┃\n     ┈┃┃┳╭╮┳┃\n     ┈╰┫╰━━╯┃\n     ▔▔╰━━━━╯\n🌸 *This coffee is for you* 🌸\n🌸 *Have a nice day* 🌸");

}));

DarkWinzo.newcmdaddtoDark({pattern: 'enm6', fromMe: false, dontAdCommandList: true}, (async (message, match) => {

    await message.sendMessage("*Hello*\n🌷🌹🍃🌹🌷 W\n┏╮╭┓┏╮╭┓       H\n╰╭╮╯╰╭╮╯       A\n╭╰╯╮╭╰╯╮       T\n┗╯╰┛┗╯╰┛       S\n🌷🌹🍃🌹🌷 \n┏╮╭┓┏╮╭┓       U\n╰╭╮╯╰╭╮╯       P\n╭╰╯╮╭╰╯╮ \n┗╯╰┛┗╯╰┛       \n🌷🌹🍃🌹🌷 \n┏╮╭┓┏╮╭┓       \n╰╭╮╯╰╭╮╯       \n╭╰╯╮╭╰╯╮       \n┗╯╰┛┗╯╰┛  \n🌷🌹🍃🌹🌷");

}));
