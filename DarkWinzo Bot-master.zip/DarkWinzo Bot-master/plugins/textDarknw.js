/* Codded by @Isuru Lakshan


Telegram: t.me/Isuru

Licensed under the  GPL-3.0 License;
you may not use this file except in compliance with the License.

Whats bot - DarkWinzo
*/

const IsuruLakshan = require('textDarkmake'); // Import NPM Package

const DarkWinzo = require('../events');
const {MessageType, GroupSettingChange, Mimetype, MessageOptions} = require('@adiwajshing/baileys');
const fs = require('fs');
const Config = require('../config')
const axios = require('axios')
const request = require('request');
const os = require('os');
var desc_msg = ''
if (Config.LANG == 'SI') desc_msg = 'ටෙක්ස්ට් මේකර් ටූල්ස්.'
if (Config.LANG == 'EN') desc_msg = 'Shows textmaker tools with unlimited access.'

let wk = Config.WORKTYPE == 'public' ? false : true
if (Config.PSW !== 'isuru') {
DarkWinzo.newcmdaddtoDark({pattern: '1text$', fromMe: wk, desc: desc_msg}, (async (message, match) => {
    var t1 = ''
    var t2 = ''
    var t3 = ''
    var t4 = ''
    var t5 = ''
    var t6 = ''
    var t7 = ''
    var t8 = ''
    var t9 = ''
    var t10 = ''
    var t11 = ''
    var t12 = ''
    var t13 = ''
    var t14 = ''
    var t15 = ''
    var t16 = ''
    var t17 = ''
    var t18 = ''
    var t19 = ''
    var t20 = ''
    var t21 = ''
    var t22 = ''
    var t23 = ''
    var t24 = ''
    var t25 = ''
    var t26 = ''
    var t27 = ''
    var t28 = ''
    var t29 = ''
    
        t1 = 'Makes Devil Themed Logo.' // https://textpro.me/create-neon-devil-wings-text-effect-online-free-1014.html
        t2 = 'Makes Logo With Bear Icon.' // https://textpro.me/online-black-and-white-bear-mascot-logo-creation-1012.html
        t3 = 'Makes Logo With Neon Effect.' // https://textpro.me/create-a-futuristic-technology-neon-light-text-effect-1006.html
        t4 = 'Makes Logo With Second Neon Effect.' // https://textpro.me/neon-text-effect-online-879.html
        t5 = 'Makes Lightning Themed Logo.' // https://textpro.me/thunder-text-effect-online-881.html
        t6 = 'Makes Joker Themed Logo.' // https://textpro.me/create-logo-joker-online-934.html
        t7 = 'Makes Ninja Themed Logos.' // https://textpro.me/create-ninja-logo-online-935.html
        t8 = 'Makes Glitter Themed Logo.' // https://textpro.me/advanced-glow-text-effect-873.html
        t9 = 'Makes Logo With Bokeh Effect.' // https://textpro.me/bokeh-text-effect-876.html
        t10 = 'Makes Logo With Wolf Icon.' // https://textpro.me/create-wolf-logo-galaxy-online-936.html
        t11 = 'Makes Black And White Marvel Logo.' // https://textpro.me/create-logo-style-marvel-studios-online-971.html
        t12 = 'Makes Colorful Marvel Logo.' // https://textpro.me/create-logo-style-marvel-studios-ver-metal-972.html
        t13 = 'Makes The Avengers Logo.' // https://textpro.me/create-3d-avengers-logo-online-974.html
        t14 = 'Makes Logo With Glitch Effect.' // https://textpro.me/create-glitch-text-effect-style-tik-tok-983.html
        t15 = 'Makes Graffiti Themed Logo.' // https://textpro.me/create-cool-wall-graffiti-text-effect-online-1009.html
        t16 = 'Makes a Second Graffiti Themed Logo.' // https://textpro.me/create-a-cool-graffiti-text-on-the-wall-1010.html
        t17 = 'Makes Lion Themed Logo.' // https://textpro.me/create-lion-logo-mascot-online-938.html
        t18 = 'Makes a Third Neon Themed Logo.' // https://textpro.me/neon-text-effect-online-963.html
        t19 = 'Makes Ice Themed Logo.' // https://textpro.me/ice-cold-text-effect-862.html
        t20 = 'Makes Space Themed Logo.' // https://textpro.me/create-space-3d-text-effect-online-985.html
        t21 = 'Makes Logo With Smoke Effect.' // https://photooxy.com/other-design/create-an-easy-smoke-type-effect-390.html
        t22 = 'Makes a Naruto Themed Logo.' // https://photooxy.com/manga-and-anime/make-naruto-banner-online-free-378.html
        t23 = 'Makes a Glow Themed Logo.' // https://photooxy.com/logo-and-text-effects/make-smoky-neon-glow-effect-343.html        
        t25 = 'Makes Flame Themed Logo.' // https://photooxy.com/logo-and-text-effects/realistic-flaming-text-effect-online-197.html
        t26 = 'Makes a Harry Potter Themed Logo.' // https://photooxy.com/logo-and-text-effects/create-harry-potter-text-on-horror-background-178.html
        t27 = 'Makes a Fourth Neon-Themed Logo.' // https://photooxy.com/logo-and-text-effects/illuminated-metallic-effect-177.html
        t28 = 'Makes a Cemetery Themed Logo.' // https://photooxy.com/logo-and-text-effects/text-on-scary-cemetery-gate-172.html
        t29 = 'Makes a Cup Themed Logo.' // https://photooxy.com/logo-and-text-effects/put-text-on-the-cup-387.html
    var usage_cmd = ''
    var command_cmd = ''
    var desc_cmd = ''
    if (Config.LANG == 'SI') {
        usage_cmd = '🌷 *උදාහරණ:* _'
        command_cmd = '❄ *විදාන:* '
        desc_cmd = '🇱🇰*විස්තර:* _'
    } else { 
        usage_cmd = '🌷 Example : '
        command_cmd = '❄ Command : '
        desc_cmd = '🇱🇰 Description : '
    }
    const msg = command_cmd + '```.Darkdevil``` \n' + t1 + '_\n' + usage_cmd + '*.Darkdevil Isuru*\n\n' +
        command_cmd + '```.Darkbear``` \n' + desc_cmd + t2 + '_\n' + usage_cmd + '*.Darkbear Isuru*\n\n' +
        command_cmd + '```.Darkwolf``` \n' + desc_cmd + t10 + '_\n' + usage_cmd + '*.Darkwolf Isuru;Lakshan*\n\n' +
        command_cmd + '```.Darkneon```\n' + desc_cmd + t3 + '_\n' + usage_cmd + '*.Darkneon Isuru*\n\n' +
        command_cmd + '```.Dark2neon``` \n' + desc_cmd + t4 + '_\n' + usage_cmd + '*.Dark2neon Isuru*\n\n' +
        command_cmd + '```.Dark3neon``` \n' + desc_cmd + t18 + '_\n' + usage_cmd + '*.Dark3neon Isuru*\n\n' +
        command_cmd + '```.Dark4neon``` \n' + desc_cmd + t27 + '_\n' + usage_cmd + '*.Dark4neon Isuru*\n\n' +
        command_cmd + '```.Darklight``` \n' + desc_cmd + t5 + '_\n' + usage_cmd + '*.Darklight Isuru*\n\n' +
        command_cmd + '```.Darkjoker``` \n' + desc_cmd + t6 + '_\n' + usage_cmd + '*.Darkjoker Isuru*\n\n' +
        command_cmd + '```.Darkninja``` \n' + desc_cmd + t7 + '_\n' + usage_cmd + '*.Darkninja Isuru;Lakshan*\n\n' +
        command_cmd + '```.Darkglitter``` \n' + desc_cmd + t8 + '_\n' + usage_cmd + '*.Darkglitter Isuru*\n\n' +
        command_cmd + '```.Darkbokeh``` \n' + desc_cmd + t9 + '_\n' + usage_cmd + '*.Darkbokeh Isuru*\n\n' +
        command_cmd + '```.Darkmarvel``` \n' + desc_cmd + t11 + '_\n' + usage_cmd + '*.Darkmarvel Isuru;Lakshan*\n\n' +
        command_cmd + '```.Dark2marvel``` \n' + desc_cmd + t12 + '_\n' + usage_cmd + '*.Dark2marvel Isuru;Lakshan*\n\n' +
        command_cmd + '```.Darkavengers``` \n' + desc_cmd + t13 + '_\n' + usage_cmd + '*.Darkavengers Isuru;Lakshan*\n\n' +
        command_cmd + '```.Darkgraf``` \n' + desc_cmd + t15 + '_\n' + usage_cmd + '*.Darkgraf Manoj;Isuru*\n\n' +
        command_cmd + '```.Dark2graf``` \n' + desc_cmd + t16 + '_\n' + usage_cmd + '*.Dark2graf Manoj;Isuru*\n\n' +       
        command_cmd + '```.Darklion``` \n' + desc_cmd + t17 + '_\n' + usage_cmd + '*.Darklion Manoj;Isuru*\n\n' +
        command_cmd + '```.Darkice``` \n' + desc_cmd + t19 + '_\n' + usage_cmd + '*.Darkice Isuru*\n\n' +
        command_cmd + '```.Darkspace``` \n' + desc_cmd + t20 + '_\n' + usage_cmd + '*.Darkspace Isuru;Lakshan*\n\n' +
        command_cmd + '```.Darksmoke``` \n' + desc_cmd + t21 + '_\n' + usage_cmd + '*.Darksmoke Isuru*\n\n' + // Thanks for @Unique_hunter for base.
        command_cmd + '```.Darkglow``` \n' + desc_cmd + t23 + '_\n' + usage_cmd + '*.Darkglow Isuru*\n\n' +
        command_cmd + '```.Darkfire``` \n' + desc_cmd + t25 + '_\n' + usage_cmd + '*.Darkfire Isuru*\n\n' +
        command_cmd + '```.Darkharry``` \n' + desc_cmd + t26 + '_\n' + usage_cmd + '*.Darkharry Isuru*\n\n' +
        command_cmd + '```.Darkcup``` \n' + desc_cmd + t29 + '_\n' + usage_cmd + '*.Darkcup Isuru*\n\n' +
        command_cmd + '```.Darkcemetery``` \n' + desc_cmd + t28 + '_\n' + usage_cmd + '*.Darkcemetery Isuru*\n\n' +
        command_cmd + '```.Darkglitch``` \n' + desc_cmd + t14 + '_\n' + usage_cmd + '*.Darkglitch Isuru;Lakshan*\n\n'
    var r_text = new Array ();
        r_text[0] = "https://ibb.co/bvHj9dG" ;
        r_text[1] = "https://ibb.co/bvHj9dG" ;
        var i = Math.floor(2*Math.random())
        var respoimage = await axios.get(`${r_text[i]}`, { responseType: 'arraybuffer' })
        await message.sendMessage(Buffer(respoimage.data), MessageType.image, {mimetype: Mimetype.png, caption: msg + ' ᴘᴏᴡᴇʀᴅ ʙʏ DarkWinzo'  })
        }));
DarkWinzo.newcmdaddtoDark({pattern: 'Darkhorror ?(.*)', fromMe: wk, dontAdCommandList: true}, (async (message, match) => {
    isuru.rgmsa("https://textpro.me/create-green-horror-style-text-effect-online-1036.html",
        `${match[1]}`
        ).then(async (data) => { 
          try { 
              var download = async(uri, filename, callback) => {
                  await request.head(uri, async(err, res, body) => {    
                      await request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                  });
              };

              await download(`${data}`, '/root/DarkWinzoWhatsappBot/horror.jpg', async() => {                          
                  await message.client.sendMessage(message.jid,fs.readFileSync('/root/DarkWinzoWhatsappBot/horror.jpg'), MessageType.image, { caption: '*' + Config.CPK + '*' })
              })
          } catch(err) { 
              console.log(err)
          } 
    });
}));
DarkWinzo.newcmdaddtoDark({pattern: 'Darkgart ?(.*)', fromMe: wk, dontAdCommandList: true}, (async (message, match) => {
    isuru.ephoto("https://ephoto360.com/tao-hieu-ung-mui-ten-dinh-kem-chu-ky-nhieu-mau-846.html",
        `${match[1]}`
        ).then(async (data) => { 
          try { 
              var download = async(uri, filename, callback) => {
                  await request.head(uri, async(err, res, body) => {    
                      await request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                  });
              };

              await download(`${data}`, '/root/DarkWinzoWhatsappBot/gart.jpg', async() => {                          
                  await message.client.sendMessage(message.jid,fs.readFileSync('/root/DarkWinzoWhatsappBot/gart.jpg'), MessageType.image, { caption: '*' + Config.CPK + '*' })
              })
          } catch(err) { 
              console.log(err)
          } 
    });
}));
DarkWinzo.newcmdaddtoDark({pattern: 'Darkdevil ?(.*)', fromMe: wk, dontAdCommandList: true}, (async (message, match) => {
    isuru.rgmsa("https://textpro.me/create-neon-devil-wings-text-effect-online-free-1014.html",
        `${match[1]}`
        ).then(async (data) => { 
          try { 
              var download = async(uri, filename, callback) => {
                  await request.head(uri, async(err, res, body) => {    
                      await request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                  });
              };

              await download(`${data}`, '/root/DarkWinzoWhatsappBot/devil.jpg', async() => {                          
                  await message.client.sendMessage(message.jid,fs.readFileSync('/root/DarkWinzoWhatsappBot/devil.jpg'), MessageType.image, { caption: '*' + Config.CPK + '*' })
              })
          } catch(err) { 
              console.log(err)
          } 
    });
}));
DarkWinzo.newcmdaddtoDark({pattern: 'Darkbear ?(.*)', fromMe: wk, dontAdCommandList: true}, (async (message, match) => {
    isuru.rgmsa("https://textpro.me/online-black-and-white-bear-mascot-logo-creation-1012.html",
        `${match[1]}`
        ).then(async (data) => { 
          try { 
              var download = async(uri, filename, callback) => {
                  await request.head(uri, async(err, res, body) => {    
                      await request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                  });
              };

              await download(`${data}`, '/root/DarkWinzoWhatsappBot/bear.jpg', async() => {                          
                  await message.client.sendMessage(message.jid,fs.readFileSync('/root/DarkWinzoWhatsappBot/bear.jpg'), MessageType.image, { caption: '*' + Config.CPK + '*' })
              })
          } catch(err) { 
              console.log(err)
          } 
    });
}));
DarkWinzo.newcmdaddtoDark({pattern: 'Darkwolf ?(.*)', fromMe: wk, dontAdCommandList: true}, (async (message, match) => {
    var topText, bottomText; 
    if (match[1].includes(';')) {
        var split = match[1].split(';');
        topText = split[0];
        bottomText = split[1];
    } else {
        topText = match[1];
        bottomText = '';
    }
    isuru.rgmsa("https://textpro.me/create-wolf-logo-galaxy-online-936.html",
        [`${topText}`, `${bottomText}`]
        ).then(async (data) => { 
          try { 
              var download = async(uri, filename, callback) => {
                  await request.head(uri, async(err, res, body) => {    
                      await request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                  });
              };

              await download(`${data}`, '/root/DarkWinzoWhatsappBot/wolf.jpg', async() => {                          
                  await message.client.sendMessage(message.jid,fs.readFileSync('/root/DarkWinzoWhatsappBot/wolf.jpg'), MessageType.image, { caption: '*' + Config.CPK + '*' })
              })
          } catch(err) { 
              console.log(err)
          } 
    });
}));
DarkWinzo.newcmdaddtoDark({pattern: 'Darkwice ?(.*)', fromMe: wk, dontAdCommandList: true}, (async (message, match) => {
    var topText, bottomText; 
    if (match[1].includes(';')) {
        var split = match[1].split(';');
        topText = split[0];
        bottomText = split[1];
    } else {
        topText = match[1];
        bottomText = '';
    }
    isuru.rgmsa("https://textpro.me/create-layered-text-effects-online-free-1032.html",
        [`${topText}`, `${bottomText}`]
        ).then(async (data) => { 
          try { 
              var download = async(uri, filename, callback) => {
                  await request.head(uri, async(err, res, body) => {    
                      await request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                  });
              };

              await download(`${data}`, '/root/DarkWinzoWhatsappBot/wolf.jpg', async() => {                          
                  await message.client.sendMessage(message.jid,fs.readFileSync('/root/DarkWinzoWhatsappBot/wolf.jpg'), MessageType.image, { caption: '*' + Config.CPK + '*' })
              })
          } catch(err) { 
              console.log(err)
          } 
    });
}));
DarkWinzo.newcmdaddtoDark({pattern: 'Darkneon ?(.*)', fromMe: wk, dontAdCommandList: true}, (async (message, match) => {
    isuru.rgmsa("https://textpro.me/create-a-futuristic-technology-neon-light-text-effect-1006.html",
        `${match[1]}`
        ).then(async (data) => { 
          try { 
              var download = async(uri, filename, callback) => {
                  await request.head(uri, async(err, res, body) => {    
                      await request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                  });
              };

              await download(`${data}`, '/root/DarkWinzoWhatsappBot/neon.jpg', async() => {                          
                  await message.client.sendMessage(message.jid,fs.readFileSync('/root/DarkWinzoWhatsappBot/neon.jpg'), MessageType.image, { caption: '*' + Config.CPK + '*' })
              })
          } catch(err) { 
              console.log(err)
          } 
    });
}));
DarkWinzo.newcmdaddtoDark({pattern: 'Dark2neon ?(.*)', fromMe: wk, dontAdCommandList: true}, (async (message, match) => {
    isuru.rgmsa("https://textpro.me/neon-text-effect-online-879.html",
        `${match[1]}`
        ).then(async (data) => { 
          try { 
              var download = async(uri, filename, callback) => {
                  await request.head(uri, async(err, res, body) => {    
                      await request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                  });
              };

              await download(`${data}`, '/root/DarkWinzoWhatsappBot/neon2.jpg', async() => {                          
                  await message.client.sendMessage(message.jid,fs.readFileSync('/root/DarkWinzoWhatsappBot/neon2.jpg'), MessageType.image, { caption: '*' + Config.CPK + '*' })
              })
          } catch(err) { 
              console.log(err)
          } 
    });
}));
DarkWinzo.newcmdaddtoDark({pattern: 'Darklight ?(.*)', fromMe: wk, dontAdCommandList: true}, (async (message, match) => {
    isuru.rgmsa("https://textpro.me/thunder-text-effect-online-881.html",
        `${match[1]}`
        ).then(async (data) => { 
          try { 
              var download = async(uri, filename, callback) => {
                  await request.head(uri, async(err, res, body) => {    
                      await request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                  });
              };

              await download(`${data}`, '/root/DarkWinzoWhatsappBot/li.jpg', async() => {                          
                  await message.client.sendMessage(message.jid,fs.readFileSync('/root/DarkWinzoWhatsappBot/li.jpg'), MessageType.image, { caption: '*' + Config.CPK + '*' })
              })
          } catch(err) { 
              console.log(err)
          } 
    });
}));
DarkWinzo.newcmdaddtoDark({pattern: 'Darkjoker ?(.*)', fromMe: wk, dontAdCommandList: true}, (async (message, match) => {
    isuru.rgmsa("https://textpro.me/create-logo-joker-online-934.html",
        `${match[1]}`
        ).then(async (data) => { 
          try { 
              var download = async(uri, filename, callback) => {
                  await request.head(uri, async(err, res, body) => {    
                      await request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                  });
              };

              await download(`${data}`, '/root/DarkWinzoWhatsappBot/joker.jpg', async() => {                          
                  await message.client.sendMessage(message.jid,fs.readFileSync('/root/DarkWinzoWhatsappBot/joker.jpg'), MessageType.image, { caption: '*' + Config.CPK + '*' })
              })
          } catch(err) { 
              console.log(err)
          } 
    });
}));
DarkWinzo.newcmdaddtoDark({pattern: 'Darkninja ?(.*)', fromMe: wk, dontAdCommandList: true}, (async (message, match) => {
    var topText, bottomText; 
    if (match[1].includes(';')) {
        var split = match[1].split(';');
        topText = split[0];
        bottomText = split[1];
    } else {
        topText = match[1];
        bottomText = '';
    }
    isuru.rgmsa("https://textpro.me/create-ninja-logo-online-935.html",
        [`${topText}`, `${bottomText}`]
        ).then(async (data) => { 
          try { 
              var download = async(uri, filename, callback) => {
                  await request.head(uri, async(err, res, body) => {    
                      await request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                  });
              };

              await download(`${data}`, '/root/DarkWinzoWhatsappBot/ninja.jpg', async() => {                          
                  await message.client.sendMessage(message.jid,fs.readFileSync('/root/DarkWinzoWhatsappBot/ninja.jpg'), MessageType.image, { caption: '*' + Config.CPK + '*' })
              })
          } catch(err) { 
              console.log(err)
          } 
    });
}));
DarkWinzo.newcmdaddtoDark({pattern: 'Darkglitter ?(.*)', fromMe: wk, dontAdCommandList: true}, (async (message, match) => {
    isuru.rgmsa("https://textpro.me/advanced-glow-text-effect-873.html",
        `${match[1]}`
        ).then(async (data) => { 
          try { 
              var download = async(uri, filename, callback) => {
                  await request.head(uri, async(err, res, body) => {    
                      await request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                  });
              };

              await download(`${data}`, '/root/DarkWinzoWhatsappBot/tt.jpg', async() => {                          
                  await message.client.sendMessage(message.jid,fs.readFileSync('/root/DarkWinzoWhatsappBot/tt.jpg'), MessageType.image, { caption: '*' + Config.CPK + '*' })
              })
          } catch(err) { 
              console.log(err)
          } 
    });
}));
DarkWinzo.newcmdaddtoDark({pattern: 'Darkbokeh ?(.*)', fromMe: wk, dontAdCommandList: true}, (async (message, match) => {
    isuru.rgmsa("https://textpro.me/bokeh-text-effect-876.html",
        `${match[1]}`
        ).then(async (data) => { 
          try { 
              var download = async(uri, filename, callback) => {
                  await request.head(uri, async(err, res, body) => {    
                      await request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                  });
              };

              await download(`${data}`, '/root/DarkWinzoWhatsappBot/bkh.jpg', async() => {                          
                  await message.client.sendMessage(message.jid,fs.readFileSync('/root/DarkWinzoWhatsappBot/bkh.jpg'), MessageType.image, { caption: '*' + Config.CPK + '*' })
              })
          } catch(err) { 
              console.log(err)
          } 
    });
}));
DarkWinzo.newcmdaddtoDark({pattern: 'Darkmarvel ?(.*)', fromMe: wk, dontAdCommandList: true}, (async (message, match) => {
    var topText, bottomText; 
    if (match[1].includes(';')) {
        var split = match[1].split(';');
        topText = split[0];
        bottomText = split[1];
    } else {
        topText = match[1];
        bottomText = 'ㅤ';
    }
    isuru.rgmsa("https://textpro.me/create-logo-style-marvel-studios-online-971.html",
        [`${topText}`, `${bottomText}`]
        ).then(async (data) => { 
          try { 
              var download = async(uri, filename, callback) => {
                  await request.head(uri, async(err, res, body) => {    
                      await request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                  });
              };

              await download(`${data}`, '/root/DarkWinzoWhatsappBot/marvel.jpg', async() => {                          
                  await message.client.sendMessage(message.jid,fs.readFileSync('/root/DarkWinzoWhatsappBot/marvel.jpg'), MessageType.image, { caption: '*' + Config.CPK + '*' })
              })
          } catch(err) { 
              console.log(err)
          } 
    });
}));
DarkWinzo.newcmdaddtoDark({pattern: 'Dark2marvel ?(.*)', fromMe: wk, dontAdCommandList: true}, (async (message, match) => {
    var topText, bottomText; 
    if (match[1].includes(';')) {
        var split = match[1].split(';');
        topText = split[0];
        bottomText = split[1];
    } else {
        topText = match[1];
        bottomText = 'ㅤ';
    }
    isuru.rgmsa("https://textpro.me/create-3d-avengers-logo-online-974.html",
        [`${topText}`, `${bottomText}`]
        ).then(async (data) => { 
          try { 
              var download = async(uri, filename, callback) => {
                  await request.head(uri, async(err, res, body) => {    
                      await request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                  });
              };

              await download(`${data}`, '/root/DarkWinzoWhatsappBot/mar2.jpg', async() => {                          
                  await message.client.sendMessage(message.jid,fs.readFileSync('/root/DarkWinzoWhatsappBot/mar2.jpg'), MessageType.image, { caption: '*' + Config.CPK + '*' })
              })
          } catch(err) { 
              console.log(err)
          } 
    });
}));
DarkWinzo.newcmdaddtoDark({pattern: 'Darkavengers ?(.*)', fromMe: wk, dontAdCommandList: true}, (async (message, match) => {
    var topText, bottomText; 
    if (match[1].includes(';')) {
        var split = match[1].split(';');
        topText = split[0];
        bottomText = split[1];
    } else {
        topText = match[1];
        bottomText = 'ㅤ';
    }
    isuru.rgmsa("https://textpro.me/create-3d-avengers-logo-online-974.html",
        [`${topText}`, `${bottomText}`]
        ).then(async (data) => { 
          try { 
              var download = async(uri, filename, callback) => {
                  await request.head(uri, async(err, res, body) => {    
                      await request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                  });
              };

              await download(`${data}`, '/root/DarkWinzoWhatsappBot/aven.jpg', async() => {                          
                  await message.client.sendMessage(message.jid,fs.readFileSync('/root/DarkWinzoWhatsappBot/aven.jpg'), MessageType.image, { caption: '*' + Config.CPK + '*' })
              })
          } catch(err) { 
              console.log(err)
          } 
    });
}));
DarkWinzo.newcmdaddtoDark({pattern: 'Darkglitch ?(.*)', fromMe: wk, dontAdCommandList: true}, (async (message, match) => {
    var topText, bottomText; 
    if (match[1].includes(';')) {
        var split = match[1].split(';');
        topText = split[0];
        bottomText = split[1];
    } else {
        topText = match[1];
        bottomText = 'ㅤ';
    }
    isuru.rgmsa("https://textpro.me/create-glitch-text-effect-style-tik-tok-983.html",
        [`${topText}`, `${bottomText}`]
        ).then(async (data) => { 
          try { 
              var download = async(uri, filename, callback) => {
                  await request.head(uri, async(err, res, body) => {    
                      await request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                  });
              };

              await download(`${data}`, '/root/DarkWinzoWhatsappBot/tt2.jpg', async() => {                          
                  await message.client.sendMessage(message.jid,fs.readFileSync('/root/DarkWinzoWhatsappBot/tt2.jpg'), MessageType.image, { caption: '*' + Config.CPK + '*' })
              })
          } catch(err) { 
              console.log(err)
          } 
    });
}));
DarkWinzo.newcmdaddtoDark({pattern: 'Darkgraf ?(.*)', fromMe: wk, dontAdCommandList: true}, (async (message, match) => {
    var topText, bottomText; 
    if (match[1].includes(';')) {
        var split = match[1].split(';');
        topText = split[0];
        bottomText = split[1];
    } else {
        topText = match[1];
        bottomText = 'ㅤ';
    }
    isuru.rgmsa("https://textpro.me/create-cool-wall-graffiti-text-effect-online-1009.html",
        [`${topText}`, `${bottomText}`]
        ).then(async (data) => { 
          try { 
              var download = async(uri, filename, callback) => {
                  await request.head(uri, async(err, res, body) => {    
                      await request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                  });
              };

              await download(`${data}`, '/root/DarkWinzoWhatsappBot/ttgra.jpg', async() => {                          
                  await message.client.sendMessage(message.jid,fs.readFileSync('/root/DarkWinzoWhatsappBot/ttgra.jpg'), MessageType.image, { caption: '*' + Config.CPK + '*' })
              })
          } catch(err) { 
              console.log(err)
          } 
    });
}));
DarkWinzo.newcmdaddtoDark({pattern: 'Dark2graf ?(.*)', fromMe: wk, dontAdCommandList: true}, (async (message, match) => {
    var topText, bottomText; 
    if (match[1].includes(';')) {
        var split = match[1].split(';');
        topText = split[0];
        bottomText = split[1];
    } else {
        topText = match[1];
        bottomText = 'ㅤ';
    }
    isuru.rgmsa("https://textpro.me/create-a-cool-graffiti-text-on-the-wall-1010.html",
        [`${topText}`, `${bottomText}`]
        ).then(async (data) => { 
          try { 
              var download = async(uri, filename, callback) => {
                  await request.head(uri, async(err, res, body) => {    
                      await request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                  });
              };

              await download(`${data}`, '/root/DarkWinzoWhatsappBot/t2gra.jpg', async() => {                          
                  await message.client.sendMessage(message.jid,fs.readFileSync('/root/DarkWinzoWhatsappBot/t2gra.jpg'), MessageType.image, { caption: '*' + Config.CPK + '*' })
              })
          } catch(err) { 
              console.log(err)
          } 
    });
}));
DarkWinzo.newcmdaddtoDark({pattern: 'Darklion ?(.*)', fromMe: wk, dontAdCommandList: true}, (async (message, match) => {
    var topText, bottomText; 
    if (match[1].includes(';')) {
        var split = match[1].split(';');
        topText = split[0];
        bottomText = split[1];
    } else {
        topText = match[1];
        bottomText = 'ㅤ';
    }
    isuru.rgmsa("https://textpro.me/create-lion-logo-mascot-online-938.html",
        [`${topText}`, `${bottomText}`]
        ).then(async (data) => { 
          try { 
              var download = async(uri, filename, callback) => {
                  await request.head(uri, async(err, res, body) => {    
                      await request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                  });
              };

              await download(`${data}`, '/root/DarkWinzoWhatsappBot/lion.jpg', async() => {                          
                  await message.client.sendMessage(message.jid,fs.readFileSync('/root/DarkWinzoWhatsappBot/lion.jpg'), MessageType.image, { caption: '*' + Config.CPK + '*' })
              })
          } catch(err) { 
              console.log(err)
          } 
    });
}));
DarkWinzo.newcmdaddtoDark({pattern: 'Dark3neon ?(.*)', fromMe: wk, dontAdCommandList: true}, (async (message, match) => {
    isuru.rgmsa("https://textpro.me/neon-text-effect-online-963.html",
        `${match[1]}`
        ).then(async (data) => { 
          try { 
              var download = async(uri, filename, callback) => {
                  await request.head(uri, async(err, res, body) => {    
                      await request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                  });
              };

              await download(`${data}`, '/root/DarkWinzoWhatsappBot/neon3.jpg', async() => {                          
                  await message.client.sendMessage(message.jid,fs.readFileSync('/root/DarkWinzoWhatsappBot/neon3.jpg'), MessageType.image, { caption: '*' + Config.CPK + '*' })
              })
          } catch(err) { 
              console.log(err)
          } 
    });
}));
DarkWinzo.newcmdaddtoDark({pattern: 'Darkice ?(.*)', fromMe: wk, dontAdCommandList: true}, (async (message, match) => {
    isuru.rgmsa("https://textpro.me/ice-cold-text-effect-862.html",
        `${match[1]}`
        ).then(async (data) => { 
          try { 
              var download = async(uri, filename, callback) => {
                  await request.head(uri, async(err, res, body) => {    
                      await request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                  });
              };

              await download(`${data}`, '/root/DarkWinzoWhatsappBot/ice.jpg', async() => {                          
                  await message.client.sendMessage(message.jid,fs.readFileSync('/root/DarkWinzoWhatsappBot/ice.jpg'), MessageType.image, { caption: '*' + Config.CPK + '*' })
              })
          } catch(err) { 
              console.log(err)
          } 
    });
}));
DarkWinzo.newcmdaddtoDark({pattern: 'space ?(.*)', fromMe: wk, dontAdCommandList: true}, (async (message, match) => {
    var topText, bottomText; 
    if (match[1].includes(';')) {
        var split = match[1].split(';');
        topText = split[0];
        bottomText = split[1];
    } else {
        topText = match[1];
        bottomText = 'ㅤ';
    }
    isuru.rgmsa("https://textpro.me/create-space-3d-text-effect-online-985.html",
        [`${topText}`, `${bottomText}`]
        ).then(async (data) => { 
          try { 
              var download = async(uri, filename, callback) => {
                  await request.head(uri, async(err, res, body) => {    
                      await request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                  });
              };

              await download(`${data}`, '/root/DarkWinzoWhatsappBot/space.jpg', async() => {                          
                  await message.client.sendMessage(message.jid,fs.readFileSync('/root/DarkWinzoWhatsappBot/space.jpg'), MessageType.image, { caption: '*' + Config.CPK + '*' })
              })
          } catch(err) { 
              console.log(err)
          } 
    });
}));
DarkWinzo.newcmdaddtoDark({pattern: 'Darksmoke ?(.*)', fromMe: wk, dontAdCommandList: true}, (async (message, match) => {
    isuru.rgmsb("https://photooxy.com/other-design/create-an-easy-smoke-type-effect-390.html",
        `${match[1]}`
        ).then(async (data) => { 
          try { 
              var download = async(uri, filename, callback) => {
                  await request.head(uri, async(err, res, body) => {    
                      await request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                  });
              };

              await download(`${data}`, '/root/DarkWinzoWhatsappBot/smoke.jpg', async() => {                          
                  await message.client.sendMessage(message.jid,fs.readFileSync('/root/DarkWinzoWhatsappBot/smoke.jpg'), MessageType.image, { caption: '*' + Config.CPK + '*' })
              })
          } catch(err) { 
              console.log(err)
          } 
    });
}));
DarkWinzo.newcmdaddtoDark({pattern: 'Darklow ?(.*)', fromMe: wk, dontAdCommandList: true}, (async (message, match) => {
    var download = async(uri, filename, callback) => {
        await request.head(uri, async(err, res, body) => {    
            await request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
        });
    };
    var uri = encodeURI(match[1])
    await download(`https://api.xteam.xyz/photooxy/neonlight?text=${uri}&APIKEY=da5fb2b73ae3e451`, '/root/DarkWinzoWhatsappBot/glowttp.jpg', async() => {                          
        await message.client.sendMessage(message.jid,fs.readFileSync('/root/DarkWinzoWhatsappBot/glowttp.jpg'), MessageType.image, { caption: '*' + Config.CPK + '*' })
    })
}));
DarkWinzo.newcmdaddtoDark({pattern: 'Darkfire ?(.*)', fromMe: wk, dontAdCommandList: true}, (async (message, match) => {
    isuru.rgmsb("https://photooxy.com/logo-and-text-effects/realistic-flaming-text-effect-online-197.html",
        `${match[1]}`
        ).then(async (data) => { 
          try { 
              var download = async(uri, filename, callback) => {
                  await request.head(uri, async(err, res, body) => {    
                      await request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                  });
              };

              await download(`${data}`, '/root/DarkWinzoWhatsappBot/tfire.jpg', async() => {                          
                  await message.client.sendMessage(message.jid,fs.readFileSync('/root/DarkWinzoWhatsappBot/tfire.jpg'), MessageType.image, { caption: '*' + Config.CPK + '*' })
              })
          } catch(err) { 
              console.log(err)
          } 
    });
}));
DarkWinzo.newcmdaddtoDark({pattern: 'Darkharry ?(.*)', fromMe: wk, dontAdCommandList: true}, (async (message, match) => {
    isuru.rgmsb("https://photooxy.com/logo-and-text-effects/create-harry-potter-text-on-horror-background-178.html",
        `${match[1]}`
        ).then(async (data) => { 
          try { 
              var download = async(uri, filename, callback) => {
                  await request.head(uri, async(err, res, body) => {    
                      await request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                  });
              };

              await download(`${data}`, '/root/DarkWinzoWhatsappBot/hp.jpg', async() => {                          
                  await message.client.sendMessage(message.jid,fs.readFileSync('/root/DarkWinzoWhatsappBot/hp.jpg'), MessageType.image, { caption: '*' + Config.CPK + '*' })
              })
          } catch(err) { 
              console.log(err)
          } 
    });
}));
DarkWinzo.newcmdaddtoDark({pattern: 'Dark4neon ?(.*)', fromMe: wk, dontAdCommandList: true}, (async (message, match) => {
    isuru.rgmsb("https://photooxy.com/logo-and-text-effects/illuminated-metallic-effect-177.html",
        `${match[1]}`
        ).then(async (data) => { 
          try { 
              var download = async(uri, filename, callback) => {
                  await request.head(uri, async(err, res, body) => {    
                      await request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                  });
              };

              await download(`${data}`, '/root/DarkWinzoWhatsappBot/t4n.jpg', async() => {                          
                  await message.client.sendMessage(message.jid,fs.readFileSync('/root/DarkWinzoWhatsappBot/t4n.jpg'), MessageType.image, { caption: '*' + Config.CPK + '*' })
              })
          } catch(err) { 
              console.log(err)
          } 
    });
}));
DarkWinzo.newcmdaddtoDark({pattern: 'Darkcemetery ?(.*)', fromMe: wk, dontAdCommandList: true}, (async (message, match) => {
    isuru.rgmsb("https://photooxy.com/logo-and-text-effects/text-on-scary-cemetery-gate-172.html",
        `${match[1]}`
        ).then(async (data) => { 
          try { 
              var download = async(uri, filename, callback) => {
                  await request.head(uri, async(err, res, body) => {    
                      await request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                  });
              };

              await download(`${data}`, '/root/DarkWinzoWhatsappBot/cmth.jpg', async() => {                          
                  await message.client.sendMessage(message.jid,fs.readFileSync('/root/DarkWinzoWhatsappBot/cmth.jpg'), MessageType.image, { caption: '*' + Config.CPK + '*' })
              })
          } catch(err) { 
              console.log(err)
          } 
    });
}));
DarkWinzo.newcmdaddtoDark({pattern: 'Darkcup ?(.*)', fromMe: wk, dontAdCommandList: true}, (async (message, match) => {
    isuru.rgmsb("https://photooxy.com/logo-and-text-effects/put-text-on-the-cup-387.html",
        `${match[1]}`
        ).then(async (data) => { 
          try { 
              var download = async(uri, filename, callback) => {
                  await request.head(uri, async(err, res, body) => {    
                      await request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                  });
              };

              await download(`${data}`, '/root/DarkWinzoWhatsappBot/cup.jpg', async() => {                          
                  await message.client.sendMessage(message.jid,fs.readFileSync('/root/DarkWinzoWhatsappBot/cup.jpg'), MessageType.image, { caption: '*' + Config.CPK + '*' })
              })
          } catch(err) { 
              console.log(err)
          } 
    });
}));
}
