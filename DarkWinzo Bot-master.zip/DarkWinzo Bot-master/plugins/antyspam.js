/* Codded by @IsuruLakshan

Telegram: t.me/Isuru

Licensed under the  GPL-3.0 License;
you may not use this file except in compliance with the License.

Whats bot - DarkWinzo

*/

const DarkWinzo = require('../events');
const {MessageType} = require('@adiwajshing/baileys');
const Config = require('../config');
const Dark = ('This command for any emergency situation about any kind of WhatsApp SPAM in Group');
const DARKW = ('*************************************\n*👑ANTI SPAM CLEAR RIBBON👑*\n\n       👑By ' + Config.BOTNAME + '👑\n       \n\n\n\n```✨✨Do Not Go Up✨✨```\n*ඉහලට යෑමෙන් වලිකින්න.*\n            *Clear Ribbon*\n    _👑by      ' + Config.BOTNAME + '👑_\n    \n    \n\n```✨✨Do Not Go Up✨✨```\n*ඉහලට යෑමෙන් වලිකින්න.*\n            *Clear Ribbon*\n    _👑by      ' + Config.BOTNAME + '👑_\n    \n\n\n\n```✨✨Do Not Go Up✨✨```\n*ඉහලට යෑමෙන් වලිකින්න.*\n            *Clear Ribbon*\n    _👑by      ' + Config.BOTNAME + '👑_\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nᴘᴏᴡᴇʀᴅ ʙʏ DarkWinzo\n*************************************')
const FINAL = "THIS IS AN ANTISAPM (anti lag),"
const MuteDark = "Trying to close group for one day,"
const MUT = ".mute 1d"
const TAG = ".tag"
const SCRIPTBYDARK = "Running Clear Reban Script....000001"
DarkWinzo.newcmdaddtoDark({pattern: 'antispam', fromMe: true, delownDarkcmd: false, desc: Dark,}, (async (message, match) => {

  var msg = await message.reply('❉Safe Mode Activating....');

  await message.client.sendMessage(
    message.jid,MuteDark, MessageType.text);

    await message.client.sendMessage(
      message.jid,MUT, MessageType.text);

      await message.client.sendMessage(
        message.jid,SCRIPTBYDARK, MessageType.text);

        await message.client.sendMessage(
          message.jid,DARKW, MessageType.text);

           await message.client.sendMessage(
             message.jid,DARKW, MessageType.text);

              await message.client.sendMessage(
                message.jid,DARKW, MessageType.text);

                 await message.client.sendMessage(
                   message.jid,DARKW, MessageType.text);

                     await message.client.sendMessage(
                       message.jid,DARKW, MessageType.text);

                         await message.client.sendMessage(
                           message.jid,DARKW, MessageType.text);

                              await message.client.sendMessage(
                                message.jid,DARKW, MessageType.text);

          await message.client.sendMessage(
            message.jid,DARKW, MessageType.text);
  
         await message.client.sendMessage(
            message.jid,DARKW, MessageType.text);
            
             await message.client.sendMessage(
                message.jid,TAG, MessageType.text);

          await message.client.sendMessage(
              message.jid,DARKW, MessageType.text);

                await message.client.sendMessage(
                  message.jid,DARKW, MessageType.text);

                  await message.client.sendMessage(
                    message.jid,DARKW, MessageType.text);

                    await message.client.sendMessage(
                      message.jid,DARKW, MessageType.text);

                      await message.client.sendMessage(
                        message.jid,DARKW, MessageType.text);
                        
  }));
  
  /*
DarkWinzo.newcmdaddtoDark({pattern: 'antispambyDark', fromMe: false, delownDarkcmd: false, desc: Dark,}, (async (message, match) => {

  var msg = await message.reply('Preforming....');

  await message.client.sendMessage(
    message.jid,MuteDark, MessageType.text);

    await message.client.sendMessage(
      message.jid,MUT, MessageType.text);

      await message.client.sendMessage(
        message.jid,SCRIPTBYDARK, MessageType.text);

        await message.client.sendMessage(
          message.jid,DARKW, MessageType.text);

           await message.client.sendMessage(
             message.jid,DARKW, MessageType.text);

              await message.client.sendMessage(
                message.jid,DARKW, MessageType.text);

                 await message.client.sendMessage(
                   message.jid,DARKW, MessageType.text);

                     await message.client.sendMessage(
                       message.jid,DARKW, MessageType.text);

                         await message.client.sendMessage(
                           message.jid,DARKW, MessageType.text);

                              await message.client.sendMessage(
                                message.jid,DARKW, MessageType.text);

          await message.client.sendMessage(
            message.jid,DARKW, MessageType.text);
                        
              await message.client.sendMessage(
                message.jid,DARKW, MessageType.text);

                await message.client.sendMessage(
                  message.jid,DARKW, MessageType.text);

                  await message.client.sendMessage(
                    message.jid,DARKW, MessageType.text);
  
         await message.client.sendMessage(
            message.jid,DARKW, MessageType.text);
            
             await message.client.sendMessage(
                message.jid,TAG, MessageType.text);

          await message.client.sendMessage(
              message.jid,DARKW, MessageType.text);

                await message.client.sendMessage(
                  message.jid,DARKW, MessageType.text);

                  await message.client.sendMessage(
                    message.jid,DARKW, MessageType.text);

                    await message.client.sendMessage(
                      message.jid,DARKW, MessageType.text);

                      await message.client.sendMessage(
                        message.jid,DARKW, MessageType.text);
                        
  }));
*/
