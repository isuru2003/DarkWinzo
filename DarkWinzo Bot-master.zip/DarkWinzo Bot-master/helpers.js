/* Codded by @IsuruLakshan

Telegram: t.me/Isuru

Licensed under the  GPL-3.0 License;
you may not use this file except in compliance with the License.

Whats bot - DarkWinzo

*/

function successfullMessage(msg) {
    return "🇱🇰 *DarkWinzo👑*:  ```" + msg + "```"
}
function errorMessage(msg) {
    return "🥴 *DarkWinzo👑*:  ```" + msg + "```"
}
function infoMessage(msg) {
    return "❄ *DarkWinzo👑*:  ```" + msg + "```"
}


module.exports = {
    successfullMessage,
    errorMessage,
    infoMessage
}
